///////////////////////////////////////////////////////////////////////////////
// Class Board
//
// Stores and manipulates the positions of the pieces
///////////////////////////////////////////////////////////////////////////////


// -- Includes ---

#include "Board.h"
#include "windows.h"
#include <stdio.h>
#include <math.h>
#include <string>
using namespace std;



int initBoard[8][8] = {
						{-4, -3, -2, -5, -6, -2, -3, -4},
						{-1, -1, -1, -1, -1, -1, -1, -1},
						{ 0,  0,  0,  0,  0,  0,  0,  0},
						{ 0,  0,  0,  0,  0,  0,  0,  0},
						{ 0,  0,  0,  0,  0,  0,  0,  0},
						{ 0,  0,  0,  0,  0,  0,  0,  0},
						{ 1,  1,  1,  1,  1,  1,  1,  1},
						{ 4,  3,  2,  5,  6,  2,  3,  4}
						};

///////////////////////////////////////////////////////////////////////////////
// Constructor 
///////////////////////////////////////////////////////////////////////////////
Board::Board ()
{
	InitBoard();
}

///////////////////////////////////////////////////////////////////////////////
// InitBoard
// 
///////////////////////////////////////////////////////////////////////////////
void Board::InitBoard()
{
	
	// Set all squares to initial piece
	for(int i = 0; i<8;i++)
	{
		for(int j = 0; j < 8;j++)
		{
			board[i][j]=initBoard[j][i];
		}
	}
	
	
	whiteKing.x = 4;	// Intial King positons
	whiteKing.y = 7;
	blackKing.x = 4;
	blackKing.y = 0;

	
	castelingPossible.blackLong = 1;	// Casteling possible from start
	castelingPossible.blackShort = 1;
	castelingPossible.whiteLong = 1;
	castelingPossible.whiteShort = 1;

	
	outedCountWhite = 0;	// Number of killed pieces
	outedCountBlack = 0;

	player= 0;		// Player 0 is white
}

//////////////////////////////////////////////////////////////////////////////
// MakeMoveFromTo
//
// Puts piece on From square on the To Square, if kill, adds killed piece to outedsqaure
// Uppdates the casteling possibilities, and if casteling move, moves also the rook
///////////////////////////////////////////////////////////////////////////////
void Board::MakeMoveFromTo(int squareFromX, int squareFromY, int squareToX, int squareToY)
{
	// Checking if casteling possibilities changes due to this move

	// Is a rook moved from start position?
	if((castelingPossible.whiteShort) && board[squareFromX][squareFromY] == 5 && squareFromX == 0)
		castelingPossible.whiteShort = false;

	else if((castelingPossible.whiteLong) && board[squareFromX][squareFromY] == 5 && squareFromX == 7)
		castelingPossible.whiteLong = false;

	else if((castelingPossible.blackShort) && board[squareFromX][squareFromY] == -5 && squareFromX == 0)
		castelingPossible.blackShort = false;

	else if((castelingPossible.blackLong) && board[squareFromX][squareFromY] == -5 && squareFromX == 7)
		castelingPossible.blackLong = false;

	// Is king moving?
	else if (abs(board[squareToX][squareToY]) == 6)
	{
		SetKingPos(squareToX,squareToY);
		if(board[squareFromX][squareFromY] == 6)
		{
			castelingPossible.whiteLong = false;
			castelingPossible.whiteShort = false;
		}
		else if(board[squareFromX][squareFromY] == -6)
		{
			castelingPossible.blackLong = false;
			castelingPossible.blackShort = false;
		}
	}
	
	// If killing move, put killed piece on outed square
	if (board[squareToX][squareToY] > 0)
	{
		outedWhite[outedCountWhite++] = board[squareToX][squareToY];
	}

	else if (board[squareToX][squareToY] < 0)
	{
		outedBlack[outedCountBlack++] = board[squareToX][squareToY];

	}

	// Uppdate the From and To square 
	board[squareToX][squareToY] = board[squareFromX][squareFromY];
	board[squareFromX][squareFromY] = 0;

	// If pawn at last rank, make queen
	if(abs(board[squareToX][squareToY]) == 1 && (squareToY == 0 || squareToY == 7 ) )
	{
		board[squareToX][squareToY] = 5 * (1 - 2 * player);
	}

	
	player = !player;	// Change player
}



//////////////////////////////////////////////////////////////////////////////
// IsLegalMove
// 
///////////////////////////////////////////////////////////////////////////////

bool Board::IsLegalMove(int squareFromX, int squareFromY, int squareToX, int squareToY)
{

	switch(abs(board[squareFromX][squareFromY])) 
	{
	case 1:	if(!IsLegalPawnMove(squareFromX,  squareFromY,  squareToX,  squareToY))
				return false;
			break;
		
	case 2:	if(!IsLegalBishopMove(squareFromX,  squareFromY,  squareToX,  squareToY))
				return false;
			break;

	case 3: if(!IsLegalKnightMove(squareFromX,  squareFromY,  squareToX,  squareToY))
				return false;
			break;
	
	case 4: if(!IsLegalRookMove(squareFromX,  squareFromY,  squareToX,  squareToY))
				return false;
			break;
	
	case 5: if(!IsLegalQueenMove(squareFromX,  squareFromY,  squareToX,  squareToY))
				return false;
			break;

	case 6:		if (!IsLegalKingMove(squareFromX,  squareFromY,  squareToX,  squareToY))
				return false;
				break;
	}
	
	return true;
}

//////////////////////////////////////////////////////////////////////////////
// IsLegalPawnMove
// 
///////////////////////////////////////////////////////////////////////////////
bool Board::IsLegalPawnMove(int squareFromX, int squareFromY, int squareToX, int squareToY)
{
	if(IsEmptySquare(squareToX,squareToY))
	{
		if(squareFromX==squareToX) // Pawns moves straight
		{
			if(POV(squareToY) - POV(squareFromY) == 1 || (POV(squareFromY)==1 && POV(squareToY) - POV(squareFromY) == 2))
			{
				return true;
			}
		}

	}
	else // Pawns killes diagonaly
	{
		if (POV(squareToY) - POV(squareFromY) == 1 && abs(POV(squareToX) - POV(squareFromX) ) == 1 )
		{
			return true;
		}
	}

	return false;
}

//////////////////////////////////////////////////////////////////////////////
// IsLegalBishopMove
// 
///////////////////////////////////////////////////////////////////////////////
bool Board::IsLegalBishopMove(int squareFromX, int squareFromY, int squareToX, int squareToY)
{
	if ( abs(squareToX - squareFromX) == abs(squareToY - squareFromY)) // Only diagonal move is legal
	{
		int dist = abs(squareToX - squareFromX)-1;
		int i = 0;
		int j = 0;

		// Go trough all the diagonal between To and From square and check for obstacle
		while(abs(i) < dist)
		{
			if(squareToX - squareFromX > 0)
				i++;
			else
				i--;
			if(squareToY - squareFromY > 0)
				j++;
			else
				j--;

			if(GetPieceOnSquare(squareFromX+i,squareFromY+j)!=0)
			{
				return false;
			}	
		}
		return true;
	}
	return false;
}

//////////////////////////////////////////////////////////////////////////////
// IsLegalRookMove
// 
///////////////////////////////////////////////////////////////////////////////
bool Board::IsLegalRookMove(int squareFromX, int squareFromY, int squareToX, int squareToY)
{

	if(squareFromX == squareToX || squareFromY == squareToY) // Only straight moves legal
	{
		int dist = (abs(squareToX - squareFromX)-1 )* (squareFromY == squareToY) + (abs(squareToY - squareFromY)-1)*(squareFromX == squareToX);
		int i = 0;
		int j = 0;

		// Go trough all the squares between To and From square and check for obstacle
		while(abs(i) < dist && abs(j) < dist)
		{
			if(squareToX - squareFromX > 0)
				i++;
			else if (squareToX - squareFromX < 0)
				i--;
			if(squareToY - squareFromY > 0)
				j++;
			else if(squareToY - squareFromY < 0)
				j--;

			if( GetPieceOnSquare(squareFromX+i,squareFromY+j) !=0 )
			{
				return false;
			}
			
		}
		return true;
	}
	else
		return false;
}

//////////////////////////////////////////////////////////////////////////////
// IsLegalKingMove
// 
///////////////////////////////////////////////////////////////////////////////
bool Board :: IsLegalKingMove(int squareFromX,  int squareFromY,  int squareToX,  int squareToY)
{
	/*
	if( squareFromX == 4 && POV(squareFromY == 0) && POV(squareToY == 0) && (squareToX == 2 || squareToX == 6) )
	{
		if(IsLegalCasteling( squareToX, squareToY, castelingCorner))
			return true;
	}*/

	if( abs(squareToX - squareFromX) + abs(squareToY- squareFromY) == 1 || abs(squareToX - squareFromX) == abs(squareToY- squareFromY) )
		return true;
	else
		return false;
}

//////////////////////////////////////////////////////////////////////////////
// IsLegalCastelingMove
// Not used at moment!!!!!
///////////////////////////////////////////////////////////////////////////////
bool Board:: IsLegalCasteling(int squareToX, int squareToY, int *castelingCorner) //Under construction. Not in use.
{
	if(squareToY == 0 && squareToX == 2)
	{
		*castelingCorner = 1;
		if(castelingPossible.blackLong &&!KingIsChecked() && !PieceIsUnderThreat(0,0) )
			return true;
	}
	else if(squareToY == 0 && squareToX == 6)
	{
		*castelingCorner = 2;
		if(castelingPossible.blackLong &&!KingIsChecked() && !PieceIsUnderThreat(7,0)  )
			return true;
	}
	else if(squareToY == 7 && squareToX == 2)
	{
		*castelingCorner = 3;
		if(castelingPossible.whiteLong && !KingIsChecked() && !PieceIsUnderThreat(0,7) )
			return true;
	}
	else if(squareToY == 7 && squareToX == 6)
	{
		*castelingCorner = 4;
		if(castelingPossible.blackShort && !KingIsChecked() && !PieceIsUnderThreat(7,7))
			return true;
	}
	
	return false;

}


//////////////////////////////////////////////////////////////////////////////
// IsLegalQueenMove
// 
///////////////////////////////////////////////////////////////////////////////
bool Board:: IsLegalQueenMove(int squareFromX,  int squareFromY,  int squareToX,  int squareToY)
{
	// Queen moves as rook and bishop
	if(IsLegalRookMove(squareFromX,  squareFromY,  squareToX,  squareToY) || IsLegalBishopMove(squareFromX,  squareFromY,  squareToX,  squareToY) )
		return true;
	else return false;
}

//////////////////////////////////////////////////////////////////////////////
// IsLegalKnightMove
// 
///////////////////////////////////////////////////////////////////////////////
bool Board:: IsLegalKnightMove(int squareFromX,  int squareFromY,  int squareToX,  int squareToY)
{
	int distX = abs(squareToX - squareFromX);
	int distY = abs(squareToY - squareFromY);
	if ( distX + distY == 3 && distX >= 1 && distY >= 1)
		return true;
	else 
		return false;
}

//////////////////////////////////////////////////////////////////////////////
// KingIsChecked
// 
///////////////////////////////////////////////////////////////////////////////
bool Board :: KingIsChecked()
{
	return PieceIsUnderThreat(GetKingPos(!player).x, GetKingPos(!player).y);
}


//////////////////////////////////////////////////////////////////////////////
// PieceIsUnderThreat
// 
///////////////////////////////////////////////////////////////////////////////
bool Board::PieceIsUnderThreat(int pieceX, int pieceY)
{

	// Check for all pieces if legal to atack this piece
	for(int sqY = 0; sqY < 8; sqY++)
	{
		for(int sqX = 0; sqX < 8; sqX++)
		{
			if(IsFriendlyPiece(sqX,sqY))
			{
				if(IsLegalMove(sqX,sqY, pieceX, pieceY) )
				{
					return true;
				}
			}
		}
	}
	return false;
}

//////////////////////////////////////////////////////////////////////////////
// GetKingPos
//
///////////////////////////////////////////////////////////////////////////////
Piece Board::GetKingPos(int pl)
{
	if (pl == 0)
		return whiteKing;
	else
		return blackKing;
}

//////////////////////////////////////////////////////////////////////////////
// SetKingPos
//
///////////////////////////////////////////////////////////////////////////////
void Board::SetKingPos(int sqX, int sqY)
{
	if (player == 0)
	{
		whiteKing.x = sqX;
		whiteKing.y = sqY;
	}
	else
	{
		blackKing.x = sqX;
		blackKing.y = sqY;
	}
		
}

//////////////////////////////////////////////////////////////////////////////
// GetPLayer
//
///////////////////////////////////////////////////////////////////////////////
int Board::GetPlayer()
{
	return player;
}

//////////////////////////////////////////////////////////////////////////////
// SetPLayer
//
///////////////////////////////////////////////////////////////////////////////
void Board::SetPlayer(int pl)
{
	player = pl;
}

//////////////////////////////////////////////////////////////////////////////
// GetPieceOnSquare
//
///////////////////////////////////////////////////////////////////////////////
int Board::GetPieceOnSquare(int squareX, int squareY)
{
	return board[squareX][squareY];
}

//////////////////////////////////////////////////////////////////////////////
// SetPlayer
//
///////////////////////////////////////////////////////////////////////////////
void Board::SetPieceOnSquare(int piece, int squareX, int squareY)
{
	board[squareX][squareY] = piece;
}

//////////////////////////////////////////////////////////////////////////////
// GetPieceOnWhiteOutedSquare
//
///////////////////////////////////////////////////////////////////////////////
int Board::GetPieceOnWhiteOutedSquare(int square)
{
	return outedWhite[square];
}

//////////////////////////////////////////////////////////////////////////////
// GetPieceOnBlackOutedSquare
//
///////////////////////////////////////////////////////////////////////////////
int Board::GetPieceOnBlackOutedSquare(int square)
{
	return outedBlack[square];
}



//////////////////////////////////////////////////////////////////////////////
// IsEmptySquare
// 
///////////////////////////////////////////////////////////////////////////////
bool Board:: IsEmptySquare(int squareX, int squareY)
{
	if (board[squareX][squareY]==0)
		return true;
	else
		return false;
}


//////////////////////////////////////////////////////////////////////////////
// POV
// Point of View, makes it possible to use same functions for both sides
///////////////////////////////////////////////////////////////////////////////
int Board::POV(int squareNumber){
	if(player==1)
		return squareNumber;
	else 
		return 7-squareNumber;
}

//////////////////////////////////////////////////////////////////////////////
// IsFriendlyPiece
// 
///////////////////////////////////////////////////////////////////////////////
bool Board:: IsFriendlyPiece(int piece)
{

	if( (player == 0 && piece > 0) || (player == 1 && piece < 0) )
		return true;
	else
		return false;
}

//////////////////////////////////////////////////////////////////////////////
// IsFriendlyPiece
// 
///////////////////////////////////////////////////////////////////////////////
bool Board::IsFriendlyPiece(int squareX, int squareY)
{

	int piece = GetPieceOnSquare(squareX,squareY); 

	if( (player == 0 && piece > 0) || (player == 1 && piece < 0) )
		return true;
	else
		return false;
}


