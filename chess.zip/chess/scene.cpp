///////////////////////////////////////////////////////////////////////////////
// Class Scene
// 
// Prints stuff on the screen
///////////////////////////////////////////////////////////////////////////////

// -- Includes ---

#include "scene.h"
#include "windows.h"
#include <stdio.h>


static SDL_Surface *mScreen;										// Screen
static Uint32 mColors [COLOR_MAX] = {0x000000ff,					// Colors
                               0xff0000ff, 0x00ff00ff, 0x0000ffff,
                               0x00ffffff, 0xff00ffff, 0xffff00ff,
                               0xffffffff,0x493D26, 0xFFF8C6};

///////////////////////////////////////////////////////////////////////////////
// Constructor
//
// 
///////////////////////////////////////////////////////////////////////////////

Scene::Scene(Board *pBoard)
{
	myBoard = pBoard;
	InitGraph ();

	// Board bounderies
	x1 = 640/2-SQUARE_SIZE*4;
	y1 = 480/2-SQUARE_SIZE*4;
	x2 = 640/2+SQUARE_SIZE*4;
	y2 = 480/2+SQUARE_SIZE*4;
}

///////////////////////////////////////////////////////////////////////////////
// UpdateScreen
///////////////////////////////////////////////////////////////////////////////
void Scene::UpdateScreen()
{
	SDL_Flip(mScreen);
}

///////////////////////////////////////////////////////////////////////////////
// GetScreenHeight
///////////////////////////////////////////////////////////////////////////////
int Scene::GetScreenHeight()
{
	return mScreen->h;
}


///////////////////////////////////////////////////////////////////////////////
// ClearScreen
///////////////////////////////////////////////////////////////////////////////
void Scene::ClearScreen() 
{
	boxColor (mScreen, 0, 0, mScreen->w - 1, mScreen->h - 1, mColors[YELLOW]);
}

///////////////////////////////////////////////////////////////////////////////
// DrawRekangle
///////////////////////////////////////////////////////////////////////////////
void Scene::DrawRectangle (int pX1, int pY1, int pX2, int pY2, enum color pC)
{
	boxColor (mScreen, pX1, pY1, pX2, pY2-1, mColors[pC]);
}

///////////////////////////////////////////////////////////////////////////////
// DrawChessBoard
//
///////////////////////////////////////////////////////////////////////////////
void Scene::DrawChessBoard()
{

	color col;

	for (int i = 0; i < 8;i++)
	{
		for(int j = 0; j<8;j++)
		{
			if ((i+j) % 2 == 0)
			{
				col = WHITE;
			}
			else
			{
				col = BROWN;
			}	
			DrawRectangle(x1 + i * SQUARE_SIZE, y1 + j * SQUARE_SIZE,x1 + (i+1) * SQUARE_SIZE,y1 + (j+1) * SQUARE_SIZE,col);
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
// MarkSquare
//
// Changes color of specified square
///////////////////////////////////////////////////////////////////////////////
void Scene::MarkSquare(int squareX, int squareY)
{
		SDL_Surface* s = CreateSurface(SQUARE_SIZE ,SQUARE_SIZE ) ;
        ( void )SDL_FillRect( s , NULL , 0xAA0000FF ) ;


        SDL_Rect rect = { SQUARE_SIZE , SQUARE_SIZE } ;

        rect.x = x1 + squareX * SQUARE_SIZE ;
        rect.y = y1 + squareY *SQUARE_SIZE ;

        ( void )SDL_FillRect( s , NULL , 0x440000FF ) ;
        ( void )SDL_BlitSurface( s , NULL , mScreen , &rect ) ;
		SDL_FreeSurface( s ) ;
}

///////////////////////////////////////////////////////////////////////////////
// Create Surface
//
///////////////////////////////////////////////////////////////////////////////
SDL_Surface* Scene:: CreateSurface( int width , int height )
{
    uint32_t rmask , gmask , bmask , amask ;

    #if SDL_BYTEORDER == SDL_BIG_ENDIAN
        rmask = 0xff000000;
        gmask = 0x00ff0000;
        bmask = 0x0000ff00;
        amask = 0x000000ff;
    #else
        rmask = 0x000000ff;
        gmask = 0x0000ff00;
        bmask = 0x00ff0000;
        amask = 0xff000000;
    #endif

    SDL_Surface* surface = SDL_CreateRGBSurface( 0 , width , height , 32 , rmask , gmask , bmask , amask ) ;
    if( surface == NULL ) 
    {
        ( void )fprintf(stderr, "CreateRGBSurface failed: %s\n", SDL_GetError() );
        exit(1);
    }

return surface ;
}

///////////////////////////////////////////////////////////////////////////////
// Draw Pieces
//
///////////////////////////////////////////////////////////////////////////////
bool Scene::DrawPieces()
{
	// Draw pieces still on board
	int piece, x, y;
	for(int sqX = 0; sqX < 8; sqX++)
	{
		for(int sqY = 0; sqY < 8; sqY++)
		{
			piece = myBoard->GetPieceOnSquare(sqX,sqY);
			x = x1 + SQUARE_SIZE*sqX;
			y = y1 + SQUARE_SIZE*sqY;
			PutPiece(x,y, piece);
		}
	}

	// Draw killed pieces putside board
	for(int i = 0; i < myBoard->outedCountWhite; i++)
	{
		
		if (i >= 8)
		{
			y = y2 + SQUARE_SIZE * 2;
			x = x1 + SQUARE_SIZE * (i-7);
		}
		else
		{
			x = x1 + SQUARE_SIZE * (i);
			y = y2 + SQUARE_SIZE * 1;
		}
		piece = myBoard->GetPieceOnWhiteOutedSquare(i);
		PutPiece(x,y, piece);
	}

	for(int i=0;i<myBoard->outedCountBlack;i++)
	{
		
		if (i >= 8)
		{
			y = y1 - SQUARE_SIZE * 1;
			x = x1 + SQUARE_SIZE * (i-7);
		}
		else
		{
			x = x1 + SQUARE_SIZE * (i);
			y = y1 - SQUARE_SIZE * 2;
		}
		piece = myBoard->GetPieceOnBlackOutedSquare(i);

		PutPiece(x,y, piece);
	}
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// PutPiece
//
// Adds image of piece
///////////////////////////////////////////////////////////////////////////////
void Scene::PutPiece(int x, int y, int piece)
{
			SDL_Rect source;
			source.x = 0;
			source.y = 0;
			source.w = 100;
			source.h = 100;

			SDL_Rect destination;
			destination.x = x;
			destination.y = y;
			destination.w = SQUARE_SIZE;
			destination.h = SQUARE_SIZE;
		
			SDL_Surface* bitmap;
			if(piece!=0)
			{
				switch (piece)
				{
				case BLACK_PAWN:  bitmap = SDL_LoadBMP("pieces/bP.bmp");	
					break;
				case BLACK_ROOK:  bitmap = SDL_LoadBMP("pieces/bR.bmp");
					break;
				case BLACK_KNIGHT:  bitmap = SDL_LoadBMP("pieces/bKn.bmp");
					break;
				case BLACK_BISHOP:  bitmap = SDL_LoadBMP("pieces/bB.bmp");
					break;
				case BLACK_QUEEN:  bitmap = SDL_LoadBMP("pieces/bQ.bmp");
					break;
				case BLACK_KING:  bitmap = SDL_LoadBMP("pieces/bK.bmp");
					break;
				case WHITE_PAWN: bitmap = SDL_LoadBMP("pieces/wP.bmp");
					break;
				case WHITE_ROOK:  bitmap = SDL_LoadBMP("pieces/wR.bmp");
					break;
				case WHITE_KNIGHT:  bitmap = SDL_LoadBMP("pieces/wKn.bmp");
					break;
				case WHITE_BISHOP:  bitmap = SDL_LoadBMP("pieces/wB.bmp");
					break;
				case WHITE_QUEEN:  bitmap = SDL_LoadBMP("pieces/wQ.bmp");
					break;
				case WHITE_KING:  bitmap = SDL_LoadBMP("pieces/wK.bmp");
					break;
				default:  bitmap = SDL_LoadBMP("pieces/wK.bmp");
					break;
				}

				// Make white color of image transparant
				SDL_SetColorKey( bitmap, SDL_SRCCOLORKEY, SDL_MapRGB(bitmap->format, 255, 255, 255) );

				SDL_BlitSurface(bitmap,&source,mScreen,&destination);
			}
}
///////////////////////////////////////////////////////////////////////////////
// CreateScene
//
///////////////////////////////////////////////////////////////////////////////
void Scene::CreateScene()
{
	ClearScreen();
	DrawChessBoard();
	DrawPieces();
}

///////////////////////////////////////////////////////////////////////////////
// InitGraph
//
///////////////////////////////////////////////////////////////////////////////
int Scene::InitGraph()
{
	const SDL_VideoInfo *info;
	Uint8  video_bpp;
	Uint32 videoflags;
        
	// Initialize SDL
	if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		return 1;
	}
	atexit(SDL_Quit);
	
	info = SDL_GetVideoInfo();
	if ( info->vfmt->BitsPerPixel > 8 ) {
		video_bpp = info->vfmt->BitsPerPixel;
	} else {
		video_bpp = 16;
	}
	videoflags = SDL_SWSURFACE | SDL_DOUBLEBUF;
	
	// Set 640x480 video mode
	if ( (mScreen=SDL_SetVideoMode(640,480,video_bpp,videoflags)) == NULL ) {
		fprintf(stderr, "Couldn't set %ix%i video mode: %s\n",640,480,SDL_GetError());
		return 2;
	}
    return 0;
}




