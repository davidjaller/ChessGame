///////////////////////////////////////////////////////////////////////////////
// Class Board
//
// Stores and manipulates the positions of the pieces
///////////////////////////////////////////////////////////////////////////////

#ifndef _BOARD_
#define _BOARD_

// ------ Includes -----

#include <iostream>
#include <stdio.h>

// ------ Defines -----

#define SQUARE_SIZE 40

#define BLACK_PAWN -1
#define BLACK_BISHOP -2
#define BLACK_KNIGHT -3
#define BLACK_ROOK -4
#define BLACK_QUEEN -5
#define BLACK_KING -6

#define WHITE_PAWN 1
#define WHITE_BISHOP 2
#define WHITE_KNIGHT 3
#define WHITE_ROOK 4
#define WHITE_QUEEN 5
#define WHITE_KING 6

// --- Types ---
typedef struct
	{
		int x;
		int y;
	}Piece;
typedef struct
	{
		bool whiteLong;
		bool whiteShort;
		bool blackLong;
		bool blackShort;
	}BoolStruct;

class Board
{
public:
	// CONSTRUCTOR
	Board();
	
	// VARIABLES
	int outedCountWhite;
	int outedCountBlack;

	// FUNCTIONS

	int GetPieceOnSquare(int squareY, int squareX);
	void SetPieceOnSquare(int piece, int squareX, int squareY);
	bool IsEmptySquare(int squareX, int squareY);
	void MakeMoveFromTo(int squareFromX, int squaereFromY, int squareToX, int squareToY);
	void InitBoard();
	int GetPieceOnWhiteOutedSquare(int square);
	int GetPieceOnBlackOutedSquare(int square);

	Piece GetKingPos(int pl);
	
	bool IsFriendlyPiece(int piece);
	bool IsFriendlyPiece( int squareX, int squareY);
	bool KingIsChecked();
	bool IsLegalMove(int squareFromX, int squareFromY, int squareToX, int squareToY);
	void SetPlayer(int pl);
	int GetPlayer();
	void SetKingPos(int sqX, int sqY);

private:

	// VARIABLES
	int board[8][8];
	int player;

	Piece whiteKing;
	Piece blackKing;

	int outedWhite[16];
	int outedBlack[16];

	BoolStruct castelingPossible;
	

	// FUNKTIONS
	bool PieceIsUnderThreat(int pieceX, int pieceY);
	int POV(int squareNumber);

	bool IsLegalPawnMove(int squareFromX, int squareFromY, int squareToX, int squareToY);
	bool IsLegalBishopMove(int squareFromX, int squareFromY, int squareToX, int squareToY);
	bool IsLegalRookMove(int squareFromX, int squareFromY, int squareToX, int squareToY);
	bool IsLegalKingMove(int squareFromX, int squareFromY, int squareToX, int squareToY);
	bool IsLegalQueenMove(int squareFromX, int squareFromY, int squareToX, int squareToY);
	bool IsLegalKnightMove(int squareFromX, int squareFromY, int squareToX, int squareToY);
	bool IsLegalCasteling(int squareToX, int squareToY, int *castelingCorner);
	
	
};

#endif // _BOARD_
