///////////////////////////////////////////////////////////////////////////////
// Class Game
// Controls the happenings of the chessgame
///////////////////////////////////////////////////////////////////////////////

// ------ Includes -----
#ifndef LINUX
#include <windows.h>
#include <math.h>
#endif
#include "Game.h"


///////////////////////////////////////////////////////////////////////////////
// Constructor
//
///////////////////////////////////////////////////////////////////////////////
Game::Game(Scene *pScene, Board *pBoard)
{
	myBoard = pBoard;
	myScene = pScene;
	state = 1;
}

///////////////////////////////////////////////////////////////////////////////
// NewGame

///////////////////////////////////////////////////////////////////////////////
void Game::NewGame()
{
	tempBoard.InitBoard();
	myBoard->InitBoard();
	myScene->CreateScene();
}

///////////////////////////////////////////////////////////////////////////////
// GameStep
// State machine that waits for user input, checks if legal, and if so makes move
///////////////////////////////////////////////////////////////////////////////
void Game::GameStep()
{

	if(state == 1)
	{
		// Wait for user input
		SDL_Event myEvent;
		while(SDL_PollEvent(&myEvent))
		{
			if(myEvent.type == SDL_MOUSEBUTTONDOWN)
			{
				if(PositionWhitinBoard(myEvent.button.x, myEvent.button.y) == true)
				{
					// Map coordinates to square
					squareFromX = int( floor( float(myEvent.button.x - myScene->x1) / float(SQUARE_SIZE) ) );
					squareFromY = int( floor( float(myEvent.button.y - myScene->y1) / float(SQUARE_SIZE) ) );
					
					activePiece = myBoard->GetPieceOnSquare(squareFromX,squareFromY);
					if(myBoard->IsFriendlyPiece(activePiece))
					{
						myScene->MarkSquare(squareFromX,squareFromY); // Mark square with active piece
						state = 2;
						break;
					}
				}
			}
		}
	}
	//-------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------------------------------
	else if(state == 2)
	{
		SDL_Event mEvent;

		// Wait for next user input
		while(SDL_WaitEvent(&mEvent))
		{
			if(mEvent.type == SDL_MOUSEBUTTONDOWN)
			{
				if(PositionWhitinBoard(mEvent.button.x, mEvent.button.y) == true)
				{
					squareToX = int( floor( float(mEvent.button.x - myScene->x1) / float(SQUARE_SIZE) ) );
					squareToY = int( floor( float(mEvent.button.y - myScene->y1) / float(SQUARE_SIZE) ) );
					
					if(!myBoard->IsFriendlyPiece(squareToX, squareToY))
					{
						myScene->MarkSquare(squareToX,squareToY);
						state = 3;
						break;
					}
					else
					{
						myScene->CreateScene(); // If friendly piece choosed again, remove mark on sqaure
						state = 1;
						break;
					}
					
				}
			}
		}
		
	}
	//-------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------------------------------
	else if (state== 3)
	{
		// Check if move is legal
		if(myBoard->IsLegalMove(squareFromX, squareFromY, squareToX, squareToY))
		{
			// Make move on temporary  board and se if king becomes or remaines threatened
			tempBoard.MakeMoveFromTo(squareFromX, squareFromY, squareToX, squareToY);

			if(!tempBoard.KingIsChecked())
			{
				// If king is not checked, make real bord as temporary board
				*myBoard = tempBoard;
				myScene->CreateScene();
				myScene->MarkSquare(squareFromX, squareFromY);
				myScene->MarkSquare(squareToX, squareToY);
				myScene->UpdateScreen();
				Sleep(1000);
				myScene->CreateScene();
				state = 1;
			}
			else
			{
				// If king is checked, take back temporary move
				tempBoard = *myBoard;
				myScene->CreateScene();
				state = 1;

			}
		}
		else
		{
			myScene->CreateScene();
			state = 1;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
// PositionWhitinBoard

///////////////////////////////////////////////////////////////////////////////
bool Game:: PositionWhitinBoard(int x, int y)
{
	 if(x > myScene->x1 && x < myScene->x2 && y > myScene->y1 && y < myScene-> y2)
		 return true;
	 else
		 return false;
}




