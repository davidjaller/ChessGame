///////////////////////////////////////////////////////////////////////////////
// Class Game
// Controls the happenings of the chessgame
///////////////////////////////////////////////////////////////////////////////

#ifndef _GAME_
#define _GAME_

// ------ Includes -----
#include <fstream>
#include <iostream>

#include "Board.h"
#include "Scene.h"
#include <time.h>

 
class Game
{
public:
	// CONSTRUCTOR
	Game			(Scene *pScene, Board *pBoard);

	// FUNCTIONS
	void GameStep	();
	void NewGame();
	

private:
	// VARIABLES
	Scene *myScene;
	Board *myBoard;
	int state;
	
	
	int squareFromX;
	int squareFromY;
	int squareToX;
	int squareToY;

	int activePiece;
	
	Board tempBoard;

	// FUNCTIONS
	bool PositionWhitinBoard(int x, int y);
};

#endif // _GAME_
