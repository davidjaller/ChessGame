///////////////////////////////////////////////////////////////////////////////
// Class Scene
// 
// Prints stuff on the screen
///////////////////////////////////////////////////////////////////////////////


// --- Includes ---
#pragma once

#include <SDL.h>									
#include "SDL_gfxprimitives.h"	
#include "board.h"
//#endif
#pragma comment (lib, "../../SDL-1.2.15/lib/x86/SDL.lib")

//#pragma comment (lib, "SDL/SDL_GfxPrimitives/SDL_GfxPrimitives_Static.lib")

// ------ Enums -----

enum color {BLACK, RED, GREEN, BLUE, CYAN, MAGENTA, YELLOW, WHITE, BROWN, LIGHT, COLOR_MAX}; // Colors

class Scene
{
public:

	// CONSTRUCTOR
	Scene(Board *pBoard);

	// FUNCTIONS
	void DrawChessBoard();
	void UpdateScreen();
	int GetScreenHeight();
	void ClearScreen();
	bool DrawPieces();
	
	void MarkSquare(int squareX, int squareY);
	void CreateScene();

	// VARIABLES
	// Board bounderies
	int x1; 
	int x2;
	int y1;
	int y2;

private:

	// FUNCTIONS
	
	int InitGraph();
	void LoadPieces();
	void DrawRectangle (int pX1, int pY1, int pX2, int pY2, enum color pC);
	SDL_Surface* CreateSurface(int width , int height);
	void PutPiece(int x, int y, int piece);
	

	// VARIABLES
	SDL_Surface * bitmap;
	Board *myBoard;

	
};

