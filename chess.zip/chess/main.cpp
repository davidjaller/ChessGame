/*****************************************************************************************
Program: Chess Game

Author: David Jaller
/*****************************************************************************************/

#include "scene.h"
#include "Game.h"
#ifndef LINUX
#include <windows.h>
#endif

#include <fstream>
#include <iostream>
using namespace std;

#include <stdio.h>

///////////////////////////////////////////////////////////////////////////////
// IsKeyDown
//
///////////////////////////////////////////////////////////////////////////////
int IsKeyDown (int pKey)
{
	Uint8* mKeytable;
	int mNumkeys;
	SDL_PumpEvents();
	mKeytable = SDL_GetKeyState(&mNumkeys);
	return mKeytable[pKey];
}

///////////////////////////////////////////////////////////////////////////////
// PrintInt
//
// For debug
///////////////////////////////////////////////////////////////////////////////
void PrintInt(int var, string varName)
{
	char str[255];
	for(int i = 0; i<varName.size() ; i++)
	{
		str[i] = varName[i];
	}
	OutputDebugString(varName.c_str());
	sprintf_s(str, ":  ");
	OutputDebugString(str);
	sprintf_s(str, "%i\n",var);
	OutputDebugString(str);

}

///////////////////////////////////////////////////////////////////////////////
// Main
//
///////////////////////////////////////////////////////////////////////////////

#ifndef LINUX
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)	
#else
int main()
#endif

{
	
	Board myBoard; 
	Scene myScene(&myBoard);
	Game myGame(&myScene, &myBoard);

	myScene.CreateScene();
	myScene.UpdateScreen();

	// Main loop
	while(!IsKeyDown (SDLK_ESCAPE))
	{
		myGame.GameStep();
		myScene.UpdateScreen();

		if(IsKeyDown(SDLK_F1))
		{
			myGame.NewGame();
		}
	}
	
}


